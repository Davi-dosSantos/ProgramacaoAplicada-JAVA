
import javax.swing.JFrame;

public class Lab7_01
{
   // execute application
   public static void main(String[] args)
   {
      Lab7_01_JFrame application = new Lab7_01_JFrame();
      application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   } 
} // end class Lab7_01

import javax.swing.*;

// Aplicativo de teste. 
public class ProdutoEscalarTest 
{ 
	public static void main(String[] args) 
	{
      	ProdutoEscalarFrame janela = new ProdutoEscalarFrame();
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	} 
} // fim da classe ProdutoEscalarTest

import javax.swing.*;

// Aplicativo de teste que exibe triangulo de pascal. 
public class PascalTest 
{ 
	public static void main(String[] args) 
{
      	PascalFrame janela = new PascalFrame();
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	} 
} // fim da classe PascalTest
